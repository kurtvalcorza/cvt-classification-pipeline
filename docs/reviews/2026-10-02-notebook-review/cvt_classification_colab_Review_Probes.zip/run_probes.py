"""Row 17 probes: tutorials/cvt_classification_colab.ipynb at the reviewed commit (3b30a28, blob 5d9e491c).

CPU only (CUDA_VISIBLE_DEVICES=-1), install skipped via the notebook's DIMER_NOTEBOOK_CI_PREINSTALLED hook,
pinned build venv (torch 2.14.0, torchvision 0.29.0, transformers 4.57.6, safetensors 0.8.0, numpy 2.5.3,
pillow 11.3.0, huggingface-hub 0.36.2 = the notebook PINS). The four snapshot data files are hard-linked from a
local copy; cell 9 writes the manifest fresh and verify_snapshot re-hashes every file. The CIFAR-10 subset is
fetched by cell 11 itself from its pinned Hugging Face URL. google.colab.files.upload is replaced by a shim
(BYOD probes) except where a probe removes it on purpose.
Usage: python run_probes.py <worktree> <weights_src> <workdir>
"""
import contextlib
import hashlib
import io
import json
import math
import os
import platform
import re
import sys
import time
import types
import zipfile
from pathlib import Path

WT, WSRC, WORK = (Path(a) for a in sys.argv[1:4])
NB = WT / "tutorials" / "cvt_classification_colab.ipynb"
RESULTS = {"env": {}, "static": {}, "cells": [], "probes": {}}
OUT = Path(__file__).with_name("results.json")
T_START = time.time()


def save():
    OUT.write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]


def src(i):
    return "".join(cells[i]["source"])


code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ---------------------------------------------------------------- static
st = RESULTS["static"]
st["nbformat"] = [nb.get("nbformat"), nb.get("nbformat_minor")]
st["n_cells"], st["n_code"], st["code_idx"] = len(cells), len(code_idx), code_idx
st["metadata_dimer"] = nb["metadata"].get("dimer")
st["outputs_present"] = sum(len(c.get("outputs", [])) for c in cells if c["cell_type"] == "code")
compile_err = {}
for i in code_idx:
    try:
        compile(src(i), f"cell{i}", "exec")
    except SyntaxError as e:
        compile_err[i] = str(e)
st["compile_errors"] = compile_err
alltext = "\n".join(src(i) for i in range(len(cells)))
md = "\n".join(src(i) for i in range(len(cells)) if cells[i]["cell_type"] == "markdown")
st["pip_install_in_kernel"] = "'pip', 'install'" in src(3)
st["uses_uv"] = bool(re.search(r"\buv (venv|pip)\b", alltext))
st["restart_instruction_in_cell3"] = "Restart the runtime" in src(3)
st["cellView_form_cells"] = [i for i in code_idx if cells[i]["metadata"].get("cellView") == "form"]
st["guided_markers"] = {k: (k.lower() in md.lower()) for k in [
    "How to use this notebook", "Roadmap", "Glossary", "Predict", "Check your reasoning", "What to notice",
    "What to look for", "Expected result", "Troubleshooting", "conclusion", "audience", "Infrastructure",
    "re-run", "rerun", "Input →"]}
st["what_to_look_for_count"] = len(re.findall(r"(?i)what to look for", md))
st["random_split_independence_claim"] = "independent thumbnails" in md
st["expect_roughly_chance_claim"] = "Expect roughly chance" in md
st["runtimes_not_measured_claim"] = "Runtimes are not measured" in md
st["split_is_duplicate_aware"] = "duplicate" in src(13).lower() or "group" in src(13).lower()
st["byod_dataset_writes_outputs"] = bool(re.search(r"json\.dump|write_text|writerow", src(29)))
st["byod_dataset_reload_compared"] = "TOLERANCE" in src(29) or "predicted_label" in src(29)
st["byod_dataset_unseen_split"] = src(29).count("split_dataset(")
st["declared_spec"] = nb["metadata"]["dimer"].get("notebook_spec")
# carried module identity
for i in (5, 7):
    rel = cells[i]["metadata"]["dimer"]["embedded_module"]
    body = (WT / rel).read_text(encoding="utf-8")
    st[f"cell{i}_carries"] = {"module": rel, "module_lines": len(body.splitlines()),
                              "cell_lines": len(src(i).splitlines()),
                              "module_sha256": hashlib.sha256(body.encode()).hexdigest(),
                              "cell_meta_sha256": cells[i]["metadata"]["dimer"]["module_sha256"]}
save()

# ---------------------------------------------------------------- workspace
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wdir = WORK / "weights" / "cvt-13"
wdir.mkdir(parents=True, exist_ok=True)
for name in ("README.md", "config.json", "preprocessor_config.json", "model.safetensors"):
    target = wdir / name
    if not target.exists():
        os.link(WSRC / name, target)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

UPLOADS = []


def _upload():
    return UPLOADS.pop(0)


def install_shim():
    g = types.ModuleType("google")
    gc = types.ModuleType("google.colab")
    gcf = types.ModuleType("google.colab.files")
    gcf.upload = _upload
    gc.files = gcf
    g.colab = gc
    sys.modules.update({"google": g, "google.colab": gc, "google.colab.files": gcf})


def remove_shim():
    for k in ("google", "google.colab", "google.colab.files"):
        sys.modules.pop(k, None)


install_shim()
ns = {"__name__": "__main__"}


def run_cell(i, source=None, label=None):
    buf = io.StringIO()
    t0 = time.time()
    rec = {"cell": i, "label": label or f"cell {i}"}
    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            exec(compile(source if source is not None else src(i), f"cell{i}", "exec"), ns)
        rec["status"] = "ok"
    except Exception as exc:  # noqa: BLE001
        rec["status"] = "error"
        rec["error"] = f"{type(exc).__name__}: {exc}"[:800]
    rec["seconds"] = round(time.time() - t0, 1)
    rec["stdout"] = buf.getvalue()[-3000:]
    RESULTS["cells"].append(rec)
    save()
    print(rec["label"], rec["status"], rec["seconds"], rec.get("error", ""), flush=True)
    return rec


def with_fields(i, **fields):
    s = src(i)
    for k, v in fields.items():
        s, n = re.subn(rf"^{k} = .*$", lambda _m, k=k, v=v: f"{k} = {v!r}", s, count=1, flags=re.M)
        assert n == 1, k
    return s


def wilson(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [round(c - h, 3), round(c + h, 3)]


def metrics(m):
    return {k: m.get(k) for k in ("accuracy", "balanced_accuracy", "n", "per_class_recall")}


P = RESULTS["probes"]

PART = os.environ.get("PROBE_PART", "all")  # "all", or "byod": re-run only P7/P8 after a minimal setup
if PART == "byod":
    RESULTS = json.loads(OUT.read_text(encoding="utf-8"))
    P = RESULTS["probes"]
    for i in (3, 5, 7, 9, 11, 13):
        run_cell(i, label=f"P7/8 setup cell {i}")
    run_cell(19, chr(10).join(l for l in src(19).splitlines() if "@param" in l), label="P7/8 setup cell 19 form fields only")
import numpy as np  # noqa: E402
import torch  # noqa: E402
from PIL import Image  # noqa: E402
if PART == "all":
    # ---------------------------------------------------------------- P1 default path, every code cell in order
    for i in code_idx:
        r = run_cell(i, label=f"P1 cell {i}")
        if r["status"] != "ok":
            break
    import numpy as np  # noqa: E402
    import torch  # noqa: E402
    from PIL import Image  # noqa: E402

    RESULTS["env"] = {"python": platform.python_version(), "torch": torch.__version__,
                      "transformers": __import__("transformers").__version__, "cuda": torch.cuda.is_available(),
                      "threads": torch.get_num_threads(), "executable": sys.executable, "platform": platform.platform()}
    try:
        P["P1_default"] = {
            "dataset_manifest": ns["dataset_manifest"], "archive_sha256": ns["archive_info"]["sha256"],
            "split": {"train": len(ns["train_records"]), "held_out": len(ns["held_out"]), "unseen": len(ns["unseen"])},
            "zero_shot": metrics(ns["zero_shot"]), "untrained": metrics(ns["untrained"]),
            "fine_tuned": metrics(ns["adapted"]), "unseen": metrics(ns["unseen_metrics"]),
            "finetune": {k: ns["run"][k] for k in ("trainable_parameters", "total_parameters", "epoch_losses", "device")},
            "degenerate": ns["degenerate"], "adapted_degenerate": {k: [(x["label"], round(x["score"], 3)) for x in v]
                                                                    for k, v in ns["adapted_degenerate"].items()},
            "reload_check": ns["reload_check"], "artifact_tensors": ns["descriptor"]["tensors"],
            "outputs": sorted(p.name for p in (WORK / "outputs").iterdir() if p.is_file()),
            "cell_seconds_total": round(sum(c["seconds"] for c in RESULTS["cells"] if c["label"].startswith("P1")), 1),
        }
    except Exception as exc:  # noqa: BLE001
        P["P1_default"] = {"error": repr(exc)}
    save()

    # ---------------------------------------------------------------- P2 pixel-duplicate leakage across the split
    try:
        dig = ns["_pixel_digest"]
        train_d = {}
        for r in ns["train_records"]:
            train_d.setdefault(dig(r["image"]), set()).add(r["label"])
        with zipfile.ZipFile(WORK / "data" / ns["SAMPLE_DATASET_FILE"]) as z:
            names = [n for n in z.namelist() if n.lower().endswith(".png")]
        top = sorted({n.split("/")[0] for n in names})
        sub = sorted({"/".join(n.split("/")[:-1]) for n in names})
        groups = {}
        for r in ns["records"]:
            groups.setdefault(dig(r["image"]), []).append((r["id"], r["label"]))
        dup_groups = [g for g in groups.values() if len(g) > 1]
        cross_label = [g for g in dup_groups if len({lab for _, lab in g}) > 1]

        def leaked(part):
            return [r for r in part if dig(r["image"]) in train_d]

        lh, lu = leaked(ns["held_out"]), leaked(ns["unseen"])
        clean_h = [r for r in ns["held_out"] if dig(r["image"]) not in train_d]
        clean_u = [r for r in ns["unseen"] if dig(r["image"]) not in train_d]
        P2 = {"archive_folders": sub[:12], "archive_top": top, "duplicate_groups": len(dup_groups),
              "group_sizes": sorted({len(g) for g in dup_groups}), "example_group": dup_groups[0] if dup_groups else None,
              "cross_label_groups": len(cross_label),
              "held_out_with_pixel_copy_in_train": f"{len(lh)}/{len(ns['held_out'])}",
              "unseen_with_pixel_copy_in_train": f"{len(lu)}/{len(ns['unseen'])}",
              "clean_held_out_n": len(clean_h), "clean_unseen_n": len(clean_u)}
        if clean_h:
            P2["fine_tuned_on_clean_held_out"] = metrics(ns["adapter"].evaluate(clean_h, majority=ns["TRAIN_MAJORITY"]))
            P2["zero_shot_on_clean_held_out"] = metrics(ns["pipe"].zero_shot_evaluate(clean_h, ns["IMAGENET_GROUPS"],
                                                                                        majority=ns["TRAIN_MAJORITY"]))
            P2["fine_tuned_on_leaked_held_out"] = metrics(ns["adapter"].evaluate(lh, majority=ns["TRAIN_MAJORITY"])) if lh else None
        if clean_u:
            P2["fine_tuned_on_clean_unseen"] = metrics(ns["adapter"].evaluate(clean_u, majority=ns["TRAIN_MAJORITY"]))
        # are darkened/original pairs pixel-identical by name number?
        P2["sample_ids_in_one_group"] = dup_groups[:3]
        P["P2_leakage"] = P2
    except Exception as exc:  # noqa: BLE001
        P["P2_leakage"] = {"error": repr(exc)}
    save()

    # ---------------------------------------------------------------- P3 untrained head across init seeds ("Expect roughly chance")
    P["P3_untrained_seeds"] = []
    try:
        for seed in (0, 1, 2, 3, 4):
            p = ns["CvtPipeline"].from_pretrained(weights_dir=ns["WEIGHTS_DIR"], class_names=ns["SAMPLE_CLASSES"], seed=seed)
            m = p.evaluate(ns["held_out"], majority=ns["TRAIN_MAJORITY"])
            P["P3_untrained_seeds"].append({"seed": seed, "accuracy": m["accuracy"], "balanced": m["balanced_accuracy"],
                                            "wilson95": wilson(round(m["accuracy"] * m["n"]), m["n"])})
            del p
            save()
    except Exception as exc:  # noqa: BLE001
        P["P3_untrained_seeds"].append({"error": repr(exc)})
    save()

    # ---------------------------------------------------------------- P4 learner reruns only the fine-tune cell after FREEZE_BACKBONE=True
    s19f = with_fields(19, FREEZE_BACKBONE=True)
    r19 = run_cell(19, s19f, label="P4 rerun cell 19 only, FREEZE_BACKBONE=True")
    P4 = {"cell19": r19["status"], "cell19_stdout": r19["stdout"][-900:]}
    for i in (21, 23, 25):
        r = run_cell(i, label=f"P4 cell {i} after freeze-only rerun")
        P4[f"cell{i}"] = r["status"]
        P4[f"cell{i}_error"] = r.get("error")
    try:
        P4["held_out_after"] = metrics(ns["adapted"])
        P4["frozen_prefixes_saved"] = ns["descriptor"]["frozen_prefixes"]
        P4["artifact_tensors"] = ns["descriptor"]["tensors"]
    except Exception as exc:  # noqa: BLE001
        P4["err"] = repr(exc)
    P["P4_stale_rerun_freeze"] = P4
    save()

    # ---------------------------------------------------------------- P5 proper head-only experiment (Try next #1): re-run 17 -> 25
    P5 = {}
    for i in (17, 19, 21, 23, 25):
        s = s19f if i == 19 else None
        r = run_cell(i, s, label=f"P5 cell {i} FREEZE_BACKBONE=True from cell 17")
        P5[f"cell{i}"] = r["status"]
        if r["status"] != "ok":
            P5[f"cell{i}_error"] = r.get("error")
            break
        if i == 19:
            P5["fine_tune_seconds"] = r["seconds"]
    try:
        P5["trainable"] = [ns["run"]["trainable_parameters"], ns["run"]["total_parameters"]]
        P5["held_out"] = metrics(ns["adapted"])
        P5["artifact_tensors"] = ns["descriptor"]["tensors"]
        P5["reload_check"] = ns["reload_check"]
    except Exception as exc:  # noqa: BLE001
        P5["err"] = repr(exc)
    P5["default_fine_tune_seconds"] = next((c["seconds"] for c in RESULTS["cells"] if c["label"] == "P1 cell 19"), None)
    P["P5_head_only"] = P5
    save()

    # ---------------------------------------------------------------- P6 Try next #2: lower PER_CLASS (re-run 11 -> 21)
    P6 = {}
    for i in (11, 13, 15, 17, 19, 21):
        s = with_fields(11, PER_CLASS=10) if i == 11 else None
        r = run_cell(i, s, label=f"P6 cell {i} PER_CLASS=10")
        if r["status"] != "ok":
            P6[f"cell{i}_error"] = r.get("error")
            break
    try:
        P6["split"] = [len(ns["train_records"]), len(ns["held_out"]), len(ns["unseen"])]
        P6["zero_shot"] = metrics(ns["zero_shot"])
        P6["untrained"] = metrics(ns["untrained"])
        P6["fine_tuned"] = metrics(ns["adapted"])
    except Exception as exc:  # noqa: BLE001
        P6["err"] = repr(exc)
    P["P6_per_class_10"] = P6
    save()


# ---------------------------------------------------------------- P7 BYOD image branch
def png_bytes(img, fmt="PNG"):
    b = io.BytesIO()
    img.save(b, format=fmt)
    return b.getvalue()


byod = WORK / "byod_inputs"
byod.mkdir(exist_ok=True)
frog = next(r for r in ns["records"] if r["label"] == "frog")["image"]
(byod / "frog.png").write_bytes(png_bytes(frog.resize((224, 224))))
(byod / "notes.png").write_bytes(b"this is text, not an image")
Image.new("RGB", (5000, 10), (9, 9, 9)).save(byod / "wide.png")
P7 = {}
for tag, path in (("ok_path", byod / "frog.png"), ("text_as_png", byod / "notes.png"), ("wide_5000px", byod / "wide.png"),
                  ("missing_path", byod / "nope.png")):
    r = run_cell(29, with_fields(29, USE_BYOD_IMAGE=True, BYOD_IMAGE_PATH=str(path)), label=f"P7 BYOD image {tag}")
    P7[tag] = {"status": r["status"], "error": r.get("error"),
               "stdout_tail": r["stdout"][-500:] if r["status"] == "ok" else None}
remove_shim()
r = run_cell(29, with_fields(29, USE_BYOD_IMAGE=True), label="P7 BYOD image empty path, no google.colab")
P7["empty_path_outside_colab"] = {"status": r["status"], "error": r.get("error")}
install_shim()
UPLOADS.append({"frog.png": png_bytes(frog)})
r = run_cell(29, with_fields(29, USE_BYOD_IMAGE=True), label="P7 BYOD image upload shim")
P7["upload_shim"] = {"status": r["status"], "error": r.get("error")}
P["P7_byod_image"] = P7
save()


# ---------------------------------------------------------------- P8 BYOD dataset branch
def drawn(color, i, size=(48, 48)):
    arr = Image.new("RGB", size, color)
    for x in range(0, size[0], 4 + i):
        for y in range(size[1]):
            arr.putpixel((x, y), (255, 255, 255))
    return png_bytes(arr)


def make_zip(path, entries):
    with zipfile.ZipFile(path, "w") as z:
        for name, data in entries:
            z.writestr(name, data)
    return path


def make_dir(path, entries):
    for name, data in entries:
        p = path / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    return path


RB = (("red", (200, 20, 20)), ("blue", (20, 20, 200)))
cases = {
    "a_folder_ok": make_dir(byod / "a_folder_ok", [(f"{c}/{j}.png", drawn(col, j)) for c, col in RB for j in range(6)]),
    "b_zip_ok": make_zip(byod / "b_zip_ok.zip", [(f"ds/{c}/{j}.png", drawn(col, j)) for c, col in RB for j in range(6)]),
    "c_class_with_one_image": make_dir(byod / "c_one", [(f"red/{j}.png", drawn((200, 20, 20), j)) for j in range(4)]
                                       + [("blue/0.png", drawn((20, 20, 200), 0))]),
    "d_one_class": make_zip(byod / "d_one_class.zip", [(f"red/{j}.png", drawn((200, 20, 20), j)) for j in range(4)]),
    "e_traversal": make_zip(byod / "e_traversal.zip", [("../evil/0.png", drawn((1, 1, 1), 0))]
                            + [(f"{c}/{j}.png", drawn(col, j)) for c, col in RB for j in range(3)]),
    "f_corrupt_member": make_zip(byod / "f_corrupt.zip", [(f"red/{j}.png", drawn((200, 20, 20), j)) for j in range(3)]
                                 + [("blue/0.png", b"not an image")] + [(f"blue/{j}.png", drawn((20, 20, 200), j)) for j in (1, 2)]),
    "g_presplit_train_val": make_zip(byod / "g_presplit.zip",
                                     [(f"train/{c}/{j}.png", drawn(col, j)) for c, col in RB for j in range(4)]
                                     + [(f"val/{c}/{j}.png", drawn(col, j + 4)) for c, col in RB for j in range(2)]),
    "h_root_images_plus_one_class": make_zip(byod / "h_root.zip", [(f"{j}.png", drawn((200, 20, 20), j)) for j in range(3)]
                                             + [(f"blue/{j}.png", drawn((20, 20, 200), j)) for j in range(3)]),
    "i_tar_path": byod / "i.tar",
}
(byod / "i.tar").write_bytes(b"x")
P8 = {}
for name, path in cases.items():
    if time.time() - T_START > 19 * 60:
        P8[name] = {"status": "not run (20-minute cap)"}
        continue
    r = run_cell(29, with_fields(29, USE_BYOD_DATASET=True, BYOD_DATASET_PATH=str(path)), label=f"P8 BYOD dataset {name}")
    rec = {"status": r["status"], "error": r.get("error")}
    if r["status"] == "ok":
        rec["stdout_tail"] = r["stdout"][-700:]
        try:
            rec["class_names"] = ns["byod_names"]
            rec["split"] = [len(ns["byod_train"]), len(ns["byod_held"])]
            rec["before"] = metrics(ns["byod_before"])
            rec["after"] = metrics(ns["byod_after"])
        except Exception as exc:  # noqa: BLE001
            rec["err"] = repr(exc)
    P8[name] = rec
    save()
P["P8_byod_dataset"] = P8
RESULTS["wall_seconds"] = round(time.time() - T_START, 1)
save()
print("done", RESULTS["wall_seconds"], flush=True)
